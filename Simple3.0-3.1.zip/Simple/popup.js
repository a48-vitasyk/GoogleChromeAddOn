document.getElementById('stopButton').addEventListener('click', function() {
    chrome.runtime.sendMessage({stopAlerts: true});
});
