document.getElementById('startButton').addEventListener('click', () => {
    chrome.runtime.sendMessage({startAlerts: true});
});

document.getElementById('stopButton').addEventListener('click', () => {
    chrome.runtime.sendMessage({stopAlerts: true});
});
