//chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
//    if (message.wordFound) {
//        let notificationOptions = {
//            type: 'basic',
//            iconUrl: 'images/icon48.png',
//            title: 'Emergency!',
//            message: 'Слово "Emergency" найдено на странице!'
//        };
//
//        chrome.notifications.create('wordFound', notificationOptions);
//
//        let playAudio = function() {
//            let audio = new Audio(chrome.runtime.getURL("beep.wav"));
//            audio.play();
//        };
//
//        chrome.scripting.executeScript({
//            target: { tabId: sender.tab.id },
//            function: playAudio,
//        });
//    }
//});

// Работает на версии 3.0
//chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
//    if (request.wordFound) {
//        let notificationOptions = {
//            type: 'basic',
//            iconUrl: 'images/icon48.png',
//            title: 'Emergency!',
//            message: '"Emergency" - tiket is UP!'
//        };
//
//        // Clear old notification before creating a new one
//        chrome.notifications.clear('wordFound', function() {
//            chrome.notifications.create('wordFound', notificationOptions);
//        });
//
//        chrome.scripting.executeScript({
//            target: { tabId: sender.tab.id },
//            func: function() {
//                let audio = new Audio(chrome.runtime.getURL("beep.wav"));
//                audio.play();
//            }
//        });
//    }
//});


let alertsOn = true;

chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    if (request.wordFound && alertsOn) {
        let notificationOptions = {
            type: 'basic',
            iconUrl: 'images/icon48.png',
            title: 'Emergency!',
            message: 'Слово "Emergency" найдено на странице!'
        };

        chrome.notifications.create('wordFound', notificationOptions);

        chrome.scripting.executeScript({
            target: { tabId: sender.tab.id },
            func: function() {
                let audio = new Audio(chrome.runtime.getURL("beep.wav"));
                audio.play();
            }
        });
    } else if (request.stopAlerts) {
        alertsOn = false;
    }
});
